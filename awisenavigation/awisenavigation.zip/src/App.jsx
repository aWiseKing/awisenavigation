import './App.css'
import Home from "./view/home/index"

function App() {
  return (
    <div class="App">
      <Home/>
    </div>
  )
}

export default App
