import { createSignal,createEffect } from "solid-js"

export const [store,setStore] = createSignal({"search_web":0})
