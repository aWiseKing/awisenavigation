import { onMount } from "solid-js"
import "./assets/css/background.css"
import { config } from "/src/assets/config.js"

function Background(){
    onMount(()=>{

    })
    return(
        <div id = "bg" class="bg bg_webp bg_jpg">
        </div>
    )
}

export default Background